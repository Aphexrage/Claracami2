import streamlit as st
import pandas as pd
from io import BytesIO

arquivo = pd.read_csv("materias_primas.csv")

def to_excel(df):
    output = BytesIO()
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        df.to_excel(writer, index=False)
    return output.getvalue()

excel_bytes = to_excel(arquivo)

st.title("Estoque de Matéria Prima")

st.dataframe(arquivo)


st.download_button(
    label="Exportar para Excel",
    data=excel_bytes,
    file_name="materias_primas.xlsx",
    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
)
