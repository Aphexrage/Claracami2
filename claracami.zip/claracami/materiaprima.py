import streamlit as st
import pandas as pd
import os

st.set_page_config(
    page_title="Cadastro | Matéria Prima",
    page_icon="📦",
)

st.title("Cadastro de Matéria Prima")

codigo = st.text_input("Código:", key="codigo_materia_prima")
nome = st.text_input("Nome:", key="nome_materia_prima")
preco = st.number_input("Preço unitário (R$):", min_value=0.0, format="%.2f", step=0.01, key="preco_unitario")
quantidade = st.selectbox("Quantidade em estoque:", options=list(range(1, 101)), key="quantidade_estoque")

if st.button("Salvar"):
    arquivo_csv = "materias_primas.csv"
    nova_materia_prima = {
        "Código": codigo,
        "Nome": nome,
        "Preço Unitário": preco,
        "Quantidade Estoque": quantidade
    }
    
    nova_linha_df = pd.DataFrame([nova_materia_prima])
    
    if os.path.exists(arquivo_csv):
        df = pd.read_csv(arquivo_csv)
        df = pd.concat([df, nova_linha_df], ignore_index=True)
    else:
        df = nova_linha_df
        
    df.to_csv(arquivo_csv, index=False)
    st.success(f"'{nome}' salva com sucesso!")

    # Limpar os input
    st.session_state.codigo_materia_prima = ""
    st.session_state.nome_materia_prima = ""
    st.session_state.preco_unitario = 0.0
    st.session_state.quantidade_estoque = 1
