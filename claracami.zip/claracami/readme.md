# 📋 Backoffice - Levantamento de Requisitos e Mapeamento de Classes

## 🚀 Requisitos Funcionais

- **🧱 Cadastro de Matérias-primas**  
  - Funcionário cadastra matérias-primas.  
  - Cadastro inclui nome, descrição, preço unitário.  
  - Atualização do estoque de matérias-primas disponível.

- **📦 Cadastro e Gerenciamento de Produtos**  
  - Usuário cadastra produtos associando matérias-primas.  
  - Permite alteração do preço dos produtos a qualquer momento.  
  - Produto possui custo calculado automaticamente com base nas matérias-primas.

- **🥘 Cadastro e Cálculo de Receitas**  
  - Usuário cria receitas agrupando produtos cadastrados.  
  - Cálculo automático do custo total da receita.  
  - Alteração no preço de qualquer produto reflete no custo da receita.  
  - Inclusão de custo de mão de obra na composição do custo da receita.

- **📊 Controle de Estoque**  
  - Aba dedicada para gerenciar estoque de matérias-primas.  
  - Funcionário informa a quantidade disponível de cada matéria-prima.  
  - Estoque é reduzido automaticamente conforme uso nas receitas/produtos.

- **📅 Cronograma de Vendas e Metas**  
  - Cronograma que calcula quantidade mínima a ser vendida para manter margem de lucro.  
  - Exemplo: se produto "brigadeiro" vendeu X na semana passada, na próxima deve vender ao menos X para alcançar lucro.  
  - Aba para acompanhamento de vendas e comparação com metas estabelecidas.

- **🔄 Atualizações e Consistência**  
  - Mudança no preço de produtos atualiza automaticamente o custo das receitas que os utilizam.  
  - Custo da mão de obra do funcionário deve ser considerado no cálculo total da receita.

---

## 🏗️ Mapeamento Inicial de Classes

### 🧱 MatériaPrima
- **Atributos:**  
  - `id`  
  - `nome`  
  - `descricao`  
  - `preco_unitario`  
  - `quantidade_estoque`
- **Métodos:**  
  - `cadastrar()`  
  - `atualizar()`  
  - `remover()`  
  - `consultar_estoque()`

---

### 📦 Produto
- **Atributos:**  
  - `id`  
  - `nome`  
  - `descricao`  
  - `preco_venda`  
  - `lista_materias_primas` (com quantidade de cada)
- **Métodos:**  
  - `cadastrar()`  
  - `alterar_preco()`  
  - `calcular_custo()`  
  - `atualizar_estoque()`

---

### 🥘 Receita
- **Atributos:**  
  - `id`  
  - `nome`  
  - `lista_produtos` (com quantidade de cada)  
  - `custo_mao_obra`  
  - `custo_total` (calculado automaticamente)
- **Métodos:**  
  - `cadastrar()`  
  - `atualizar_produtos()`  
  - `calcular_custo_receita()`  
  - `atualizar_custo_apos_alteracao_produto()`

---

### 📊 Estoque
- **Atributos:**  
  - `lista_materias_primas`
- **Métodos:**  
  - `consultar_quantidade()`  
  - `atualizar_quantidade()`  
  - `baixar_estoque_apos_producao()`

---

### 📅 CronogramaVendas
- **Atributos:**  
  - `receita` (referência)  
  - `meta_vendas_minima`  
  - `vendas_realizadas`  
  - `período` (semana/mês)
- **Métodos:**  
  - `calcular_meta_vendas()`  
  - `registrar_venda()`  
  - `verificar_atingimento_meta()`

---

### 👷‍♂️ MãoDeObra
- **Atributos:**  
  - `id_funcionario`  
  - `nome`  
  - `salario_hora`  
  - `horas_trabalhadas`  
  - `custo_total_mao_obra` (salario_hora * horas_trabalhadas)
- **Métodos:**  
  - `registrar_horas()`  
  - `calcular_custo_mao_obra()`  

---

## 📝 Observações para Desenvolvimento

- Sempre que o preço de um produto for alterado, o custo da receita que o contém deve ser recalculado.  
- O custo da mão de obra deve ser somado ao custo total da receita para refletir no preço final.  
- O sistema deve permitir visualização e atualização clara do estoque de matérias-primas.  
- O cronograma de vendas deve permitir comparar vendas reais com metas e sinalizar status (atingiu, abaixo da meta).  
- Cada aba do sistema deve estar alinhada com uma funcionalidade específica para facilitar a usabilidade e organização.

---
